<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Free web site templates by Six Shooter Media are licensed under a Creative Commons Attribution-Noncommercial 3.0 United States License.

Should you wish to waive this license and use my Free Templates in commercial projects you will need to purchase and download a copy of the Free Templates Commercial License.

Refer to http://www.sixshootermedia.com/licensing/

',
    'readme' => 'Packaged for MODx Revolution 
S. Hamblett steve.hamblett@linux.com 11/02/2010',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e6ba4fa08330bef3312cfe3782c8264e',
      'native_key' => 'motion',
      'filename' => 'modNamespace/f0013ea9bd6397545ce1b9279e2c6492.vehicle',
      'namespace' => 'motion',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => 'b0a033cc24400224180cd22a43636bd3',
      'native_key' => NULL,
      'filename' => 'modTemplate/a96135bee64825dd9658ebe25602b630.vehicle',
      'namespace' => 'motion',
    ),
  ),
);