Packaged for MODx Revolution 
S. Hamblett steve.hamblett@linux.com 11/02/2010