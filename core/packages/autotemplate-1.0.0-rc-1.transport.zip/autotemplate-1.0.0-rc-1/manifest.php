<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4718eac5d6a8872ace1b57b93e5381fc',
      'native_key' => 'autotemplate',
      'filename' => 'modNamespace/8d2545ecb5a618532cf4c7bd27acf3fd.vehicle',
      'namespace' => 'autotemplate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'ccfbb6d3a5cd74d8835334c478f7b8be',
      'native_key' => 4,
      'filename' => 'modPlugin/382d03d286e561a88727d88aae413b91.vehicle',
      'namespace' => 'autotemplate',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '70c848563adde74e6514704091f1edbf',
      'native_key' => 1,
      'filename' => 'modCategory/e060866f90d2db3f109fd480a522cd80.vehicle',
      'namespace' => 'autotemplate',
    ),
  ),
);